﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using Microsoft.Services.Store.Engagement;

namespace $safeprojectname$.Core
{
    public class ProvideFeedbackCommand : ICommand
    {
        private bool _isBusy;

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return !_isBusy && StoreServicesFeedbackLauncher.IsSupported();
        }

        public async void Execute(object parameter)
        {
            _isBusy = true;

            CanExecuteChanged?.Invoke(this, new EventArgs());

            var launcher = StoreServicesFeedbackLauncher.GetDefault();

            var dictionary = new Dictionary<string, string>
            {
                ["ExtensionId"] = parameter.ToString()
            };

            await launcher.LaunchAsync(dictionary);

            _isBusy = false;

            CanExecuteChanged?.Invoke(this, new EventArgs());
        }
    }
}
